import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../models/product.dart';
import '../providers/shop_provider.dart';
import '../widgets/glass_container.dart';

class ProductDetailsScreen extends StatelessWidget {
  final Product product;

  const ProductDetailsScreen({required this.product, super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();
    final isFavorite = provider.wishlist.contains(product.id);

    return Scaffold(
      backgroundColor: kVerdeXBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: kSoftWhite),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(product.name, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: kEmerald)),
              const SizedBox(height: 8),
              Text(product.category, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 24),
              Expanded(
                child: GlassContainer(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: Image.network(product.image, fit: BoxFit.cover, width: double.infinity),
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _priceTag(product),
                          IconButton(
                            onPressed: () => provider.toggleWishlist(product.id),
                            icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, color: isFavorite ? kEmerald : Colors.white70),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _badge('Rating', product.rating.toStringAsFixed(1)),
                          const SizedBox(width: 10),
                          _badge('Discount', '${product.discount}%'),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text('Product Overview', style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 10),
                      Text(product.description, style: const TextStyle(color: Colors.white70, height: 1.6)),
                      const Spacer(),
                      ElevatedButton(
                        onPressed: () {
                          provider.addToCart(product);
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to cart')));
                        },
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size.fromHeight(56),
                          backgroundColor: kEmerald,
                        ),
                        child: const Text('Add to Cart'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _priceTag(Product product) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [kEmerald, kDarkEmerald]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Text('\$${product.discountedPrice.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kVerdeXBlack)),
    );
  }

  Widget _badge(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
