import 'package:flutter/material.dart';
import '../widgets/glass_container.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFF090A0F)),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('About Us', style: TextStyle(fontSize: 38, color: Color(0xFF00FF8C), fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                const Text('A visionary e-commerce studio built for premium shoppers who demand immersive luxury.', style: TextStyle(fontSize: 16, color: Colors.white70)),
                const SizedBox(height: 28),
                GlassContainer(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Mission', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      Text('To craft a next-generation shopping environment where every product feels like a collectible artifact.', style: TextStyle(fontSize: 14, height: 1.6, color: Colors.white70)),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                GlassContainer(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Vision', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      Text('A carefully curated destination for shoppers who expect elegance, motion, and futuristic craftsmanship.', style: TextStyle(fontSize: 14, height: 1.6, color: Colors.white70)),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                Expanded(
                  child: GridView(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 18, mainAxisSpacing: 18, childAspectRatio: 1.05),
                    children: const [
                      _StatCard(value: '14K+', label: 'Daily Visits'),
                      _StatCard(value: '98%', label: 'Satisfaction'),
                      _StatCard(value: '120+', label: 'Curated Products'),
                      _StatCard(value: '24/7', label: 'Support'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;

  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF00FF8C))),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white70)),
          const Spacer(),
          Align(
            alignment: Alignment.bottomRight,
            child: Icon(Icons.timeline_rounded, color: Colors.white24, size: 30),
          ),
        ],
      ),
    );
  }
}
