import 'package:flutter/material.dart';
import '../widgets/glass_container.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFF050608)),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Contact', style: TextStyle(fontSize: 38, color: Color(0xFF00FF8C), fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                const Text('Connect with our support team for bespoke assistance and luxury service.', style: TextStyle(fontSize: 16, color: Colors.white70)),
                const SizedBox(height: 24),
                GlassContainer(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    children: [
                      _buildField('Name'),
                      const SizedBox(height: 12),
                      _buildField('Email'),
                      const SizedBox(height: 12),
                      _buildField('Message', maxLines: 4),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                          child: const Text('Send Message'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                GlassContainer(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Live Chat', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      Text('Tap the chat bubble at any time for instant support from our luxury concierge.', style: TextStyle(color: Colors.white70, height: 1.5)),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: GlassContainer(
                    padding: const EdgeInsets.all(18),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(28),
                              gradient: const LinearGradient(colors: [Color(0xFF020304), Color(0xFF0B0C11)]),
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text('Interactive Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            SizedBox(height: 12),
                            Expanded(
                              child: Center(
                                child: Icon(Icons.map_rounded, color: Colors.white24, size: 80),
                              ),
                            ),
                            Text('VerdeX HQ • Luxury District', style: TextStyle(color: Colors.white70)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildField(String label, {int maxLines = 1}) {
    return TextField(
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white54),
        filled: true,
        fillColor: Colors.white12,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      ),
    );
  }
}
