import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../providers/shop_provider.dart';
import '../widgets/glass_container.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();

    return Stack(
      children: [
        Container(color: kVerdeXBlack),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Cart', style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: kEmerald)),
                const SizedBox(height: 8),
                const Text('Floating items, live totals, and checkout in style.', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 24),
                Expanded(
                  child: provider.cartItems.isEmpty
                      ? const Center(child: Text('Your cart is empty. Add items to experience the VerdeX flow.', style: TextStyle(color: Colors.white70), textAlign: TextAlign.center))
                      : ListView.separated(
                          itemCount: provider.cartItems.length,
                          separatorBuilder: (context, index) => const SizedBox(height: 18),
                          itemBuilder: (context, index) {
                            final cartItem = provider.cartItems[index];
                            return GlassContainer(
                              padding: const EdgeInsets.all(18),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(22),
                                    child: Image.network(cartItem.product.image, width: 100, height: 100, fit: BoxFit.cover),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(cartItem.product.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                        const SizedBox(height: 6),
                                        Text('\$${cartItem.product.discountedPrice.toStringAsFixed(0)}', style: const TextStyle(color: kEmerald, fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 12),
                                        Row(
                                          children: [
                                            _QuantityButton(icon: Icons.remove, onTap: () => provider.updateQuantity(cartItem.product.id, cartItem.quantity - 1)),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 12),
                                              child: Text(cartItem.quantity.toString(), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                                            ),
                                            _QuantityButton(icon: Icons.add, onTap: () => provider.updateQuantity(cartItem.product.id, cartItem.quantity + 1)),
                                            const Spacer(),
                                            GestureDetector(
                                              onTap: () => provider.removeCartItem(cartItem.product.id),
                                              child: const Icon(Icons.delete_outline_rounded, color: Colors.white54),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 16),
                GlassContainer(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _priceRow('Subtotal', provider.cartSubtotal),
                      const SizedBox(height: 12),
                      _priceRow('Discount', -provider.discountValue, accent: kGlowGreen),
                      const Divider(color: Colors.white12, height: 28),
                      _priceRow('Total', provider.cartTotal, isTotal: true),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: provider.cartItems.isEmpty ? null : provider.applyCoupon,
                              style: ElevatedButton.styleFrom(backgroundColor: kDarkEmerald),
                              child: Text(provider.couponApplied ? 'Coupon Applied' : 'Apply 24% Off'),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: provider.cartItems.isEmpty ? null : () {},
                              child: const Text('Checkout'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _priceRow(String label, double amount, {bool isTotal = false, Color accent = kEmerald}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: isTotal ? 18 : 14, fontWeight: isTotal ? FontWeight.w700 : FontWeight.w500, color: Colors.white70)),
        Text(
          '${amount < 0 ? '-' : ''}\$${amount.abs().toStringAsFixed(2)}',
          style: TextStyle(fontSize: isTotal ? 20 : 14, fontWeight: FontWeight.bold, color: accent),
        ),
      ],
    );
  }
}

class _QuantityButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _QuantityButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: const Color(0xFF13171F),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, size: 18, color: Colors.white70),
      ),
    );
  }
}
