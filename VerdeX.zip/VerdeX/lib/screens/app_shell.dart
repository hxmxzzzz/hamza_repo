import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shop_provider.dart';
import 'about_screen.dart';
import 'cart_screen.dart';
import 'categories_screen.dart';
import 'contact_screen.dart';
import 'home_screen.dart';
import 'products_screen.dart';

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  static const List<Widget> pages = [
    HomeScreen(),
    ProductsScreen(),
    CategoriesScreen(),
    CartScreen(),
    AboutScreen(),
    ContactScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          pages[provider.currentIndex],
          Positioned(
            left: 20,
            right: 20,
            bottom: 18,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                child: Container(
                  height: 88,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(32),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.35),
                        blurRadius: 30,
                        offset: const Offset(0, 16),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _NavButton(index: 0, label: 'Home', icon: Icons.home_rounded),
                      _NavButton(index: 1, label: 'Shop', icon: Icons.grid_view_rounded),
                      _NavButton(index: 2, label: 'Categories', icon: Icons.layers_rounded),
                      _NavButton(index: 3, label: 'Cart', icon: Icons.shopping_bag_rounded),
                      _NavButton(index: 4, label: 'About', icon: Icons.info_rounded),
                      _NavButton(index: 5, label: 'Contact', icon: Icons.chat_rounded),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final int index;
  final String label;
  final IconData icon;

  const _NavButton({required this.index, required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();
    final selected = provider.currentIndex == index;

    return GestureDetector(
      onTap: () => provider.setIndex(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: selected
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  colors: [Color(0xFF00FF8C), Color(0xFF00B464)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF00FF8C).withValues(alpha: 0.25),
                    blurRadius: 24,
                    spreadRadius: 0,
                  )
                ],
              )
            : null,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 24, color: selected ? Colors.black : Colors.white70),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 12, color: selected ? Colors.black : Colors.white70)),
          ],
        ),
      ),
    );
  }
}
