import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shop_provider.dart';
import '../widgets/category_card.dart';
import '../widgets/glass_container.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();

    return Stack(
      children: [
        Container(color: const Color(0xFF05060A)),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Categories', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Color(0xFF00FF8C))),
                const SizedBox(height: 8),
                const Text('Explore every premium collection with layered glass motion.', style: TextStyle(fontSize: 16, color: Colors.white70)),
                const SizedBox(height: 28),
                GlassContainer(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
                  child: Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: provider.categories.map((cat) {
                      return ChoiceChip(
                        label: Text(cat.title),
                        selected: provider.activeFilter == cat.title || (provider.activeFilter == 'All' && cat.title == 'Footwear'),
                        onSelected: (_) => provider.setFilter(cat.title),
                        selectedColor: cat.accent.withValues(alpha: 0.22),
                        backgroundColor: Colors.white10,
                        labelStyle: const TextStyle(color: Colors.white),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: GridView.builder(
                    itemCount: provider.categories.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 18,
                      crossAxisSpacing: 18,
                      childAspectRatio: 1.1,
                    ),
                    itemBuilder: (context, index) {
                      return CategoryCard(category: provider.categories[index], expanded: true);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
