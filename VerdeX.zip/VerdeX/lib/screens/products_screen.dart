import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../providers/shop_provider.dart';
import '../widgets/glass_container.dart';
import '../widgets/product_card.dart';

class ProductsScreen extends StatelessWidget {
  const ProductsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();
    final products = provider.filteredProducts;

    return Stack(
      children: [
        Container(color: kVerdeXBlack),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Vault of Products', style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: kEmerald)),
                const SizedBox(height: 6),
                Text('Discover premium gear that feels alive in every interaction.', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 24),
                GlassContainer(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      const Icon(Icons.search_rounded, color: Colors.white70),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          onChanged: provider.updateSearch,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: 'Search premium products',
                            hintStyle: TextStyle(color: Colors.white54),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: provider.setFilter,
                        icon: const Icon(Icons.tune_rounded, color: Colors.white70),
                        itemBuilder: (_) => ['All', 'Footwear', 'Audio', 'Tech', 'Lifestyle']
                            .map((filter) => PopupMenuItem(value: filter, child: Text(filter)))
                            .toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                Expanded(
                  child: products.isEmpty
                      ? const Center(child: Text('No products match your search.', style: TextStyle(color: Colors.white70)))
                      : GridView.builder(
                          itemCount: products.length,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 16,
                            crossAxisSpacing: 16,
                            childAspectRatio: 0.74,
                          ),
                          itemBuilder: (context, index) {
                            return ProductCard(product: products[index]);
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
