import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../providers/shop_provider.dart';
import '../widgets/animated_background.dart';
import '../widgets/category_card.dart';
import '../widgets/glass_container.dart';
import '../widgets/product_card.dart';
import '../widgets/review_carousel.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();

    return Stack(
      children: [
        const AnimatedBackground(),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 120),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(context),
                  const SizedBox(height: 28),
                  _buildHeroBanner(context),
                  const SizedBox(height: 28),
                  _buildFeaturedCarousel(context, provider),
                  const SizedBox(height: 28),
                  _buildTrendingCategories(provider),
                  const SizedBox(height: 28),
                  _buildSectionTitle('Best Selling'),
                  const SizedBox(height: 16),
                  _buildBestSelling(provider),
                  const SizedBox(height: 28),
                  _buildSectionTitle('New Arrivals'),
                  const SizedBox(height: 16),
                  _buildNewArrivals(provider),
                  const SizedBox(height: 32),
                  const ReviewCarousel(),
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('VerdeX 3D', style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: kEmerald)),
        const SizedBox(height: 8),
        Text('Shop Beyond Reality', style: Theme.of(context).textTheme.titleLarge),
      ],
    );
  }

  Widget _buildHeroBanner(BuildContext context) {
    return GlassContainer(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Luxury shopping with floating 3D highlights, interactive motion, and premium glow.',
                    style: TextStyle(fontSize: 16, height: 1.5),
                  ),
                ),
                const SizedBox(width: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kEmerald, kDarkEmerald]),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Text('New Drop', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
                ),
              ],
            ),
            const SizedBox(height: 22),
            SizedBox(
              height: 260,
              child: Stack(
                children: [
                  Positioned(
                    right: 0,
                    top: 16,
                    child: Container(
                      width: 220,
                      height: 220,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        gradient: const RadialGradient(colors: [Color(0xFF00FF8C), Colors.transparent]),
                        boxShadow: [
                          BoxShadow(color: kEmerald.withValues(alpha: 0.18), blurRadius: 60, spreadRadius: 10),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    right: 14,
                    top: 16,
                    child: SizedBox(
                      width: 140,
                      height: 140,
                      child: Lottie.network(
                        'https://assets6.lottiefiles.com/private_files/lf30_yz18aa5e.json',
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    top: 14,
                    child: Transform.rotate(
                      angle: -0.05,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(30),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1519741494834-6efccf079e1c?auto=format&fit=crop&w=900&q=80',
                          width: 220,
                          height: 220,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 24,
                    bottom: 24,
                    child: GlassContainer(
                      blur: 18,
                      padding: const EdgeInsets.all(16),
                      width: 160,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Emerald Edition', style: TextStyle(fontSize: 13, color: Colors.white70)),
                          SizedBox(height: 8),
                          Text('Ultra Vision Lens', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturedCarousel(BuildContext context, ShopProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('Featured Products'),
        const SizedBox(height: 18),
        SizedBox(
          height: 280,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.82),
            itemCount: provider.featuredProducts.length,
            itemBuilder: (context, index) {
              return Transform.scale(
                scale: 0.96,
                child: ProductCard(product: provider.featuredProducts[index], compact: true),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTrendingCategories(ShopProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('Trending Categories'),
        const SizedBox(height: 16),
        SizedBox(
          height: 140,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: provider.categories.length,
            separatorBuilder: (context, index) => const SizedBox(width: 18),
            itemBuilder: (context, index) {
              return CategoryCard(category: provider.categories[index]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700));
  }

  Widget _buildBestSelling(ShopProvider provider) {
    return SizedBox(
      height: 220,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: provider.trendingProducts.length,
        separatorBuilder: (context, index) => const SizedBox(width: 18),
        itemBuilder: (context, index) {
          return ProductCard(product: provider.trendingProducts[index]);
        },
      ),
    );
  }

  Widget _buildNewArrivals(ShopProvider provider) {
    return SizedBox(
      height: 220,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: provider.newArrivals.length,
        separatorBuilder: (context, index) => const SizedBox(width: 18),
        itemBuilder: (context, index) {
          return ProductCard(product: provider.newArrivals[index]);
        },
      ),
    );
  }
}
