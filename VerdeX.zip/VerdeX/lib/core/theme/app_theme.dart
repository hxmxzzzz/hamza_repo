import 'package:flutter/material.dart';

const Color kVerdeXBlack = Color(0xFF0A0A0F);
const Color kSurfaceBlack = Color(0xFF101218);
const Color kEmerald = Color(0xFF00FF8C);
const Color kDarkEmerald = Color(0xFF00B464);
const Color kGlowGreen = Color(0xFF00FFB4);
const Color kSoftWhite = Color(0xFFF0F7FF);

ThemeData verdeXTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: kVerdeXBlack,
  colorScheme: ColorScheme.dark(
    primary: kEmerald,
    onPrimary: kVerdeXBlack,
    secondary: kDarkEmerald,
    onSecondary: Colors.white,
    surface: kSurfaceBlack,
    onSurface: kSoftWhite,
  ),
  textTheme: const TextTheme(
    headlineLarge: TextStyle(fontSize: 44, fontWeight: FontWeight.w800, letterSpacing: 0.5),
    headlineSmall: TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
    titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
    titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
    bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
    labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
  ).apply(bodyColor: kSoftWhite, displayColor: kSoftWhite),
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.transparent,
    elevation: 0,
    centerTitle: true,
    iconTheme: IconThemeData(color: kSoftWhite),
  ),
  cardTheme: CardThemeData(
    color: const Color(0xD9151218),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    elevation: 0,
    margin: EdgeInsets.zero,
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: kEmerald,
      foregroundColor: kVerdeXBlack,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 0,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      textStyle: const TextStyle(fontWeight: FontWeight.bold),
    ),
  ),
  snackBarTheme: const SnackBarThemeData(
    backgroundColor: Color(0xFF111418),
    contentTextStyle: TextStyle(color: kSoftWhite),
  ),
);
