class Product {
  final String id;
  final String name;
  final String category;
  final String description;
  final String image;
  final double price;
  final double rating;
  final int discount;
  final bool isNew;
  final bool isBestSeller;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.description,
    required this.image,
    required this.price,
    required this.rating,
    required this.discount,
    this.isNew = false,
    this.isBestSeller = false,
  });

  double get discountedPrice => price * (1 - discount / 100);
}
