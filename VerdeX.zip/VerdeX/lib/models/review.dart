class Review {
  final String author;
  final String comment;
  final double rating;
  final String date;

  const Review({
    required this.author,
    required this.comment,
    required this.rating,
    required this.date,
  });
}
