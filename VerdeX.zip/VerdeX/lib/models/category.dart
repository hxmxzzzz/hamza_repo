import 'package:flutter/material.dart';

class CategoryItem {
  final String id;
  final String title;
  final IconData icon;
  final String subtitle;
  final Color accent;

  const CategoryItem({
    required this.id,
    required this.title,
    required this.icon,
    required this.subtitle,
    required this.accent,
  });
}
