import 'dart:async';
import 'package:flutter/material.dart';
import '../models/category.dart';
import '../models/product.dart';
import '../models/review.dart';

class CartItem {
  final Product product;
  int quantity;
  CartItem({required this.product, this.quantity = 1});

  double get lineTotal => product.discountedPrice * quantity;
}

class ShopProvider extends ChangeNotifier {
  int currentIndex = 0;
  bool loading = true;
  bool couponApplied = false;
  String searchQuery = '';
  String activeFilter = 'All';
  final Set<String> wishlist = {};
  final List<CartItem> cartItems = [];

  ShopProvider() {
    _initializeApp();
  }

  void _initializeApp() {
    Timer(const Duration(milliseconds: 900), () {
      loading = false;
      notifyListeners();
    });
  }

  void setIndex(int index) {
    currentIndex = index;
    notifyListeners();
  }

  void toggleWishlist(String productId) {
    if (wishlist.contains(productId)) {
      wishlist.remove(productId);
    } else {
      wishlist.add(productId);
    }
    notifyListeners();
  }

  void addToCart(Product product) {
    final existing = cartItems.where((item) => item.product.id == product.id).toList();
    if (existing.isNotEmpty) {
      existing.first.quantity += 1;
    } else {
      cartItems.add(CartItem(product: product));
    }
    notifyListeners();
  }

  void updateQuantity(String productId, int quantity) {
    final item = cartItems.firstWhere((item) => item.product.id == productId);
    item.quantity = quantity.clamp(1, 99);
    notifyListeners();
  }

  void removeCartItem(String productId) {
    cartItems.removeWhere((item) => item.product.id == productId);
    notifyListeners();
  }

  void applyCoupon() {
    couponApplied = !couponApplied;
    notifyListeners();
  }

  void updateSearch(String query) {
    searchQuery = query;
    notifyListeners();
  }

  void setFilter(String filter) {
    activeFilter = filter;
    notifyListeners();
  }

  double get cartSubtotal => cartItems.fold(0.0, (sum, item) => sum + item.lineTotal);
  double get discountValue => couponApplied ? 24.0 : 0.0;
  double get cartTotal => cartSubtotal - discountValue;

  List<Product> get featuredProducts => products.where((p) => p.isBestSeller || p.isNew).toList();
  List<Product> get trendingProducts => products.where((p) => p.rating >= 4.6).toList();
  List<Product> get newArrivals => products.where((p) => p.isNew).toList();

  List<CategoryItem> get categories => _categories;

  List<Review> get reviews => _reviews;

  List<Product> get filteredProducts {
    final current = activeFilter == 'All'
        ? products
        : products.where((product) => product.category == activeFilter).toList();
    if (searchQuery.isEmpty) return current;
    return current.where((product) => product.name.toLowerCase().contains(searchQuery.toLowerCase())).toList();
  }
}

const List<CategoryItem> _categories = [
  CategoryItem(id: 'sneakers', title: 'Footwear', subtitle: 'Future-ready', icon: Icons.directions_run, accent: Color(0xFF26E5A7)),
  CategoryItem(id: 'headphones', title: 'Audio', subtitle: 'Immersive sound', icon: Icons.headphones, accent: Color(0xFF39D7F3)),
  CategoryItem(id: 'tech', title: 'Tech', subtitle: 'Smart essentials', icon: Icons.watch, accent: Color(0xFF8A60FF)),
  CategoryItem(id: 'lifestyle', title: 'Lifestyle', subtitle: 'Luxury essentials', icon: Icons.fitness_center, accent: Color(0xFFFF9E35)),
];

const List<Review> _reviews = [
  Review(author: 'Ava L.', comment: 'Every interaction feels premium. VerdeX 3D is my new shopping obsession.', rating: 4.9, date: 'May 2'),
  Review(author: 'Noah P.', comment: 'The product gallery and motion designers are gorgeous. A truly futuristic experience.', rating: 4.8, date: 'May 10'),
  Review(author: 'Mia T.', comment: 'Love the glassmorphism and neon accents. Checkout feels magical!', rating: 5.0, date: 'May 16'),
];

const List<Product> products = [
  Product(
    id: 'vx-01',
    name: 'VerdeX Flux Knit Runner',
    category: 'Footwear',
    description: 'A lightweight, sculpted runner with ambient glow and adaptive fit.',
    image: 'https://images.unsplash.com/photo-1519741494834-6efccf079e1c?auto=format&fit=crop&w=1000&q=80',
    price: 299.00,
    rating: 4.7,
    discount: 18,
    isNew: true,
    isBestSeller: true,
  ),
  Product(
    id: 'vx-02',
    name: 'Vision Core Headset',
    category: 'Audio',
    description: 'A premium headset with spatial audio, noise sculpting, and glass comfort.',
    image: 'https://images.unsplash.com/photo-1516339901601-2e1b60a5ce6f?auto=format&fit=crop&w=1000&q=80',
    price: 499.00,
    rating: 4.8,
    discount: 22,
    isNew: true,
  ),
  Product(
    id: 'vx-03',
    name: 'Orbit Smartband',
    category: 'Tech',
    description: 'Wearable intelligence with holographic gestures and advanced wellness tracking.',
    image: 'https://images.unsplash.com/photo-1511376777868-611b54f68947?auto=format&fit=crop&w=1000&q=80',
    price: 199.00,
    rating: 4.6,
    discount: 15,
  ),
  Product(
    id: 'vx-04',
    name: 'Nebula Traveler Case',
    category: 'Lifestyle',
    description: 'Carbon-fiber travel kit with invisible compartments and a floating feel.',
    image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=1000&q=80',
    price: 149.00,
    rating: 4.5,
    discount: 12,
    isBestSeller: true,
  ),
  Product(
    id: 'vx-05',
    name: 'Aurora Ambient Speaker',
    category: 'Audio',
    description: 'A sculpted speaker with soft neon layers and powerful room-filling sound.',
    image: 'https://images.unsplash.com/photo-1512499617640-c2f999017d40?auto=format&fit=crop&w=1000&q=80',
    price: 249.00,
    rating: 4.9,
    discount: 20,
    isNew: true,
  ),
];
