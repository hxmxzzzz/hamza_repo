import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../models/product.dart';
import '../providers/shop_provider.dart';
import '../screens/product_details_screen.dart';
import 'glass_container.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final bool compact;

  const ProductCard({required this.product, this.compact = false, super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();
    final isFavorite = provider.wishlist.contains(product.id);

    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductDetailsScreen(product: product)));
      },
      child: GlassContainer(
        padding: const EdgeInsets.all(14),
        width: compact ? 300 : null,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              alignment: Alignment.topRight,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.45),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Text('-${product.discount}%', style: const TextStyle(color: kEmerald, fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    left: 10,
                    top: 10,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28),
                        gradient: const RadialGradient(colors: [Color(0xFF00FF8C), Colors.transparent], radius: 0.7),
                      ),
                    ),
                  ),
                  Center(
                    child: Hero(
                      tag: product.id,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Image.network(product.image, fit: BoxFit.cover, width: double.infinity, height: 160),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text(product.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(product.category, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 10),
            Row(
              children: [
                Text('\$${product.discountedPrice.toStringAsFixed(0)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kEmerald)),
                const SizedBox(width: 10),
                Text('\$${product.price.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white38, decoration: TextDecoration.lineThrough)),
                const Spacer(),
                GestureDetector(
                  onTap: () => provider.toggleWishlist(product.id),
                  child: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, color: isFavorite ? kEmerald : Colors.white70),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => provider.addToCart(product),
              style: ElevatedButton.styleFrom(
                backgroundColor: kEmerald,
                minimumSize: const Size.fromHeight(44),
              ),
              child: const Text('Add to Cart'),
            ),
          ],
        ),
      ),
    );
  }
}
