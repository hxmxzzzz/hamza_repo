import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shop_provider.dart';
import 'glass_container.dart';

class ReviewCarousel extends StatelessWidget {
  const ReviewCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopProvider>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Customer Reviews', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        SizedBox(
          height: 190,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.88),
            itemCount: provider.reviews.length,
            itemBuilder: (context, index) {
              final review = provider.reviews[index];
              return Padding(
                padding: const EdgeInsets.only(right: 14),
                child: GlassContainer(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, color: Color(0xFF00FF8C)),
                          const SizedBox(width: 8),
                          Text(review.rating.toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                          const Spacer(),
                          Text(review.date, style: const TextStyle(color: Colors.white54)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(review.comment, style: const TextStyle(color: Colors.white70, height: 1.6)),
                      const Spacer(),
                      Text('- ${review.author}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
