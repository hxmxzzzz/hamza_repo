import 'dart:math';
import 'package:flutter/material.dart';

class AnimatedBackground extends StatefulWidget {
  const AnimatedBackground({super.key});

  @override
  State<AnimatedBackground> createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: _ParticlePainter(_controller.value),
          child: Container(color: const Color(0xFF06070E)),
        );
      },
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final double progress;
  final Random random = Random(42);

  _ParticlePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    final particleCount = 11;

    for (var i = 0; i < particleCount; i++) {
      final baseX = (i / particleCount) * size.width;
      final radius = 4 + (i % 3) * 2.5;
      final y = size.height * ((0.15 + i * 0.07) % 1) + sin(progress * 2 * pi + i) * 14;
      paint.color = Colors.greenAccent.withValues(alpha: 0.08 + (i % 3) * 0.05);
      canvas.drawCircle(Offset((baseX + sin(progress * 2 * pi + i) * 30) % size.width, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
