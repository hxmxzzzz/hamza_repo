import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/category.dart';
import 'glass_container.dart';

class CategoryCard extends StatelessWidget {
  final CategoryItem category;
  final bool expanded;

  const CategoryCard({required this.category, this.expanded = false, super.key});

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(colors: [category.accent.withValues(alpha: 0.9), category.accent.withValues(alpha: 0.35)]),
            ),
            child: Icon(category.icon, color: Colors.black, size: 28),
          ),
          const SizedBox(height: 16),
          Text(category.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(category.subtitle, style: const TextStyle(color: Colors.white70)),
          if (expanded) ...[
            const Spacer(),
            Row(
              children: const [
                Text('Explore', style: TextStyle(color: kEmerald, fontWeight: FontWeight.bold)),
                SizedBox(width: 6),
                Icon(Icons.arrow_forward_rounded, color: kEmerald, size: 18),
              ],
            )
          ]
        ],
      ),
    );
  }
}
