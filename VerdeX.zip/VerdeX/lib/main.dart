import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'providers/shop_provider.dart';
import 'screens/app_shell.dart';

void main() {
  runApp(const VerdeXApp());
}

class VerdeXApp extends StatelessWidget {
  const VerdeXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ShopProvider(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'VerdeX 3D',
        theme: verdeXTheme,
        home: const AppShell(),
      ),
    );
  }
}
